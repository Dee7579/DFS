SHIP_NAME = 'Minbari Breaching Pod'
SHIP_CLASS = 'Minbari Breaching Pod'
FILE_NAME = 'Minbari_Breaching_Pod'
FACTION_NAME = "Minbari Federation"

LEGACY_SHIP_NAMES = [
    'Breaching Pod',
    'Breaching Pod Wing',
]

PROFILES = [
    {
        'fleet': 'Minbari Federation',
        'priority': 'Patrol',
        'speed': 8,
        'turn': 'SM',
        'hull': 5,
        'damage': '-',
        'crew': '-',
        'troops': 1,
        'craft': '-',
        'in_service': '2046+',
        'traits': ['Breaching Pod', 'Dodge 5+', 'Stealth 4+'],
        'notes': ['Dogfight: -', 'Wing of Four Flights'],
        'weapons': [],
    },
]
