SHIP_NAME = 'Flyer Flight'
SHIP_CLASS = 'Flyer Flight'
FILE_NAME = 'Flyer'
FACTION_NAME = "Minbari Federation"

LEGACY_SHIP_NAMES = [
]

PROFILES = [
    {'fleet': 'Minbari Federation',
     'priority': 'Patrol',
     'speed': 12,
     'turn': 'SM',
     'hull': 4,
     'damage': None,
     'crew': None,
     'troops': None,
     'craft': 'None',
     'in_service': '2004+',
     'traits': ['Atmospheric', 'Dodge 4+', 'Fighter', 'Stealth 5+'],
     'notes': ['Wing of Four Flights. Dogfight +1.'],
     'weapons': [('Light Fusion Cannon', '2', 'T', 2, 'Mini-Beam')]},
]
