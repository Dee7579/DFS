SHIP_NAME = 'Tishat Medium Fighter Flight'
SHIP_CLASS = 'Tishat Medium Fighter Flight'
FILE_NAME = 'Tishat_Medium_Fighter'
FACTION_NAME = "Minbari Federation"

LEGACY_SHIP_NAMES = [
]

PROFILES = [
    {'fleet': 'Minbari Federation',
     'priority': 'Patrol',
     'speed': 15,
     'turn': 'SM',
     'hull': 3,
     'damage': None,
     'crew': None,
     'troops': None,
     'craft': 'None',
     'in_service': '2031+',
     'traits': ['Atmospheric', 'Dodge 2+', 'Fighter', 'Stealth 4+'],
     'notes': ['Wing of Two Flights. Dogfight +4.'],
     'weapons': [('Light Fusion Cannon', '2', 'T', 1, 'Mini-Beam')]},
]
