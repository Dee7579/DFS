SHIP_NAME = 'Breaching Pod'
SHIP_CLASS = 'Breaching Pod'
FILE_NAME = 'Breaching_Pod'
FACTION_NAME = "Minbari Federation"

LEGACY_SHIP_NAMES = [
]

PROFILES = [
    {'fleet': 'Minbari Federation',
     'priority': 'Patrol',
     'speed': 8,
     'turn': 'SM',
     'hull': 5,
     'damage': None,
     'crew': None,
     'troops': 1,
     'craft': 'None',
     'in_service': '2046+',
     'traits': ['Breaching Pod', 'Dodge 5+', 'Stealth 4+'],
     'notes': ['Wing of Four Flights. Fighter craft entry.'],
     'weapons': []},
]
