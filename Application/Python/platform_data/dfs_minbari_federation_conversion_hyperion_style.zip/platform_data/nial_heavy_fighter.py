SHIP_NAME = 'Nial Heavy Fighter Flight'
SHIP_CLASS = 'Nial Heavy Fighter Flight'
FILE_NAME = 'Nial_Heavy_Fighter'
FACTION_NAME = "Minbari Federation"

LEGACY_SHIP_NAMES = [
]

PROFILES = [
    {'fleet': 'Minbari Federation',
     'priority': 'Patrol',
     'speed': 15,
     'turn': 'SM',
     'hull': 4,
     'damage': None,
     'crew': None,
     'troops': None,
     'craft': 'None',
     'in_service': '2050+',
     'traits': ['Atmospheric', 'Dodge 2+', 'Fighter', 'Stealth 5+'],
     'notes': ['Wing of Two Flights. Dogfight +3.'],
     'weapons': [('Light Fusion Cannon', '2', 'T', 3, 'Mini-Beam')]},
]
